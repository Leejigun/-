export interface Person{
    empNm:string;
    hjNm:string;
    jpgLink:string;
    origNm:string;
    reeleGbnNm:string;
}