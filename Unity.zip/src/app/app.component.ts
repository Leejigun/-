import { Component } from '@angular/core';
import { HttpModule } from '@angular/http';

@Component({
  selector: 'app-root',
  template : '<app-search></app-search>' 
})
export class AppComponent {
  title = 'app works!';
}
